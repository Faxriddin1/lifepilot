from django.urls import path

from . import views

app_name = 'users'

urlpatterns = [
    path('register/', views.RegisterView.as_view(), name='register'),
    path('login/', views.LoginView.as_view(), name='login'),
    path('logout/', views.LogoutView.as_view(), name='logout'),
    path('me/', views.ProfileView.as_view(), name='me'),
    path('google/', views.GoogleAuthView.as_view(), name='google-auth'),
]
